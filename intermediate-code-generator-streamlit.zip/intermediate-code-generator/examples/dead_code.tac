# Dead code elimination example
a = sourceA
unused = 99
print a
