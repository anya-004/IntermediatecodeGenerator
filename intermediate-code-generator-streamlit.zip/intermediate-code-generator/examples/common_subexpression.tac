# Common sub-expression elimination example
a = sourceA
b = sourceB
t1 = a + b
t2 = a + b
print t2
