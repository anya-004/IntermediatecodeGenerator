# Constant folding example
x = 10 * 3
print x
