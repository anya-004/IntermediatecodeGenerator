"""Streamlit dashboard for the C + Flex intermediate-code optimizer."""

from __future__ import annotations

import difflib
import re
import subprocess
from pathlib import Path
from typing import Any

import streamlit as st


PROJECT_DIR = Path(__file__).resolve().parent
OPTIMIZER = PROJECT_DIR / "optimizer"

SAMPLES: dict[str, str] = {
    "Complete demonstration": """# Complete example: all three optimizations
# sourceA and sourceB stand for values supplied by an earlier stage.
a = sourceA
b = sourceB
unused = 99
sum1 = a + b
sum2 = a + b
constant = 10 * 3
answer = sum2 + constant
print answer
""",
    "Constant folding": """# The multiplication is evaluated at compile time.
x = 10 * 3
print x
""",
    "Common sub-expression elimination": """# The expression a + b is calculated once and reused.
a = sourceA
b = sourceB
t1 = a + b
t2 = a + b
print t2
""",
    "Dead code elimination": """# The value assigned to unused is never read.
a = sourceA
unused = 99
print a
""",
}


st.set_page_config(
    page_title="Intermediate Code Optimizer",
    page_icon="⚙️",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
      .main .block-container {padding-top: 1.8rem; padding-bottom: 3rem; max-width: 1450px;}
      .hero {padding: 1.35rem 1.5rem; border: 1px solid rgba(128,128,128,.25);
             border-radius: 16px; margin-bottom: 1rem;}
      .hero-kicker {font-size: .78rem; letter-spacing: .12em; text-transform: uppercase;
                     opacity: .72; font-weight: 700;}
      .hero h1 {margin: .35rem 0 .35rem 0; font-size: 2rem;}
      .hero p {margin: 0; opacity: .8;}
      .small-note {font-size: .86rem; opacity: .75;}
      div[data-testid="stMetric"] {border: 1px solid rgba(128,128,128,.22);
          padding: .8rem 1rem; border-radius: 12px;}
      .step {border: 1px solid rgba(128,128,128,.22); padding: .85rem 1rem;
             border-radius: 12px; min-height: 112px;}
      .step strong {display:block; margin-bottom:.3rem;}
    </style>
    """,
    unsafe_allow_html=True,
)


def initialize_state() -> None:
    if "tac_input" not in st.session_state:
        st.session_state.tac_input = SAMPLES["Complete demonstration"]
    if "last_result" not in st.session_state:
        st.session_state.last_result = None


def load_selected_sample() -> None:
    selected = st.session_state.get("sample_choice", "Complete demonstration")
    st.session_state.tac_input = SAMPLES[selected]
    st.session_state.last_result = None


def nonempty_statement_count(source: str) -> int:
    """Count TAC statements for display; comments and blank lines are ignored."""
    count = 0
    for line in source.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("//"):
            continue
        # The lexer accepts semicolons as statement terminators.
        count += len([part for part in line.split(";") if part.strip()])
    return count


def build_optimizer() -> tuple[bool, str]:
    try:
        completed = subprocess.run(
            ["make"],
            cwd=PROJECT_DIR,
            capture_output=True,
            text=True,
            timeout=60,
            check=False,
        )
    except FileNotFoundError:
        return False, "`make` was not found. Install build-essential and Flex in your Codespace."
    except subprocess.TimeoutExpired:
        return False, "Compilation took too long and was stopped."

    if completed.returncode != 0:
        details = (completed.stdout + "\n" + completed.stderr).strip()
        return False, details or "The optimizer could not be compiled."
    return True, (completed.stdout + completed.stderr).strip()


def execute_optimizer(source: str) -> dict[str, Any]:
    built, build_log = build_optimizer()
    if not built:
        return {"ok": False, "error": build_log}

    try:
        completed = subprocess.run(
            [str(OPTIMIZER)],
            cwd=PROJECT_DIR,
            input=source,
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "Optimization timed out. Check the input and try again."}

    if completed.returncode != 0:
        error_text = (completed.stderr or completed.stdout).strip()
        return {"ok": False, "error": error_text or "The optimizer returned an error."}

    summary = completed.stderr.strip()
    match = re.search(
        r"(\d+) input statements,\s*(\d+) removed by dead-code elimination",
        summary,
    )
    input_count = int(match.group(1)) if match else nonempty_statement_count(source)
    removed_count = int(match.group(2)) if match else 0
    output = completed.stdout.strip("\n")
    output_count = len([line for line in output.splitlines() if line.strip()])

    return {
        "ok": True,
        "input": source,
        "output": output,
        "summary": summary,
        "input_count": input_count,
        "output_count": output_count,
        "removed_count": removed_count,
        "build_log": build_log,
    }


initialize_state()

with st.sidebar:
    st.markdown("## ⚙️ Optimizer controls")
    st.caption("C implementation + Flex-generated lexical analyzer")
    st.markdown("---")
    st.markdown("**Supported optimizations**")
    st.markdown("**1. Constant folding**  \nEvaluates constant arithmetic during optimization.")
    st.markdown("**2. Common sub-expression elimination**  \nReuses an earlier expression when its operands have not changed.")
    st.markdown("**3. Dead code elimination**  \nRemoves assignments whose values are never used by observable output.")
    st.markdown("---")
    st.markdown("**Input format**")
    st.code("x = 10 * 3\ny = x + a\nprint y", language="text")
    st.caption("One three-address statement per line. Use `print` to mark observable values.")
    st.markdown("---")
    st.markdown("**Compiler pipeline**")
    st.write("TAC input → Flex lexer → C parser → optimization passes → optimized TAC")

st.markdown(
    """
    <div class="hero">
      <div class="hero-kicker">Compiler Design Mini Project</div>
      <h1>Intermediate Code Optimizer</h1>
      <p>Write or upload three-address code, run the C + Lex optimizer, and inspect the optimized output.</p>
    </div>
    """,
    unsafe_allow_html=True,
)

# Pipeline overview
pipeline_cols = st.columns(4)
pipeline_steps = [
    ("01 · Input", "Enter or upload TAC statements."),
    ("02 · Lexical analysis", "Flex tokenizes identifiers, numbers and operators."),
    ("03 · Optimization", "C applies folding, CSE and dead-code removal."),
    ("04 · Output", "Review and download optimized TAC."),
]
for col, (heading, description) in zip(pipeline_cols, pipeline_steps):
    with col:
        st.markdown(
            f'<div class="step"><strong>{heading}</strong><span class="small-note">{description}</span></div>',
            unsafe_allow_html=True,
        )

st.markdown("### Optimizer workspace")
left, right = st.columns([1, 1])

with left:
    st.selectbox(
        "Load a sample program",
        list(SAMPLES.keys()),
        key="sample_choice",
        on_change=load_selected_sample,
    )
    uploaded = st.file_uploader("Or upload a TAC file", type=["tac", "txt"], help="Upload a .tac or plain-text file.")
    load_col, clear_col = st.columns([1, 1])
    with load_col:
        if st.button("Load uploaded file", use_container_width=True, disabled=uploaded is None):
            try:
                st.session_state.tac_input = uploaded.getvalue().decode("utf-8")
                st.session_state.last_result = None
                st.rerun()
            except UnicodeDecodeError:
                st.error("The uploaded file must be UTF-8 text.")
    with clear_col:
        if st.button("Reset editor", use_container_width=True):
            st.session_state.tac_input = SAMPLES["Complete demonstration"]
            st.session_state.last_result = None
            st.rerun()

    st.text_area(
        "Input intermediate code",
        key="tac_input",
        height=330,
        help="Use supported TAC statements such as x = a + b and print x.",
    )
    run_col, count_col = st.columns([1, 1])
    with run_col:
        run_clicked = st.button("▶  Run optimizer", type="primary", use_container_width=True)
    with count_col:
        st.button(
            f"{nonempty_statement_count(st.session_state.tac_input)} input statements",
            disabled=True,
            use_container_width=True,
        )

    if run_clicked:
        if not st.session_state.tac_input.strip():
            st.error("Enter some intermediate code before running the optimizer.")
            st.session_state.last_result = None
        else:
            with st.spinner("Building the Flex scanner and running the C optimizer..."):
                st.session_state.last_result = execute_optimizer(st.session_state.tac_input)

with right:
    st.markdown("#### Optimized output")
    result = st.session_state.last_result
    if result and result.get("ok"):
        st.success("Optimization completed successfully.")
        st.code(result["output"] or "# No output statements", language="text")
        st.download_button(
            "⬇ Download optimized TAC",
            data=(result["output"] + "\n") if result["output"] else "",
            file_name="optimized.tac",
            mime="text/plain",
            use_container_width=True,
        )
    elif result:
        st.error("The optimizer could not process this input.")
        st.code(result.get("error", "Unknown error"), language="text")
    else:
        st.info("Your optimized code will appear here after you click **Run optimizer**.")
        st.code("# Waiting for input...", language="text")

if st.session_state.last_result and st.session_state.last_result.get("ok"):
    result = st.session_state.last_result
    st.markdown("### Optimization results")
    metric_cols = st.columns(4)
    metric_cols[0].metric("Input statements", result["input_count"])
    metric_cols[1].metric("Output statements", result["output_count"])
    metric_cols[2].metric("Removed by DCE", result["removed_count"])
    reduction = (
        (result["input_count"] - result["output_count"]) / result["input_count"] * 100
        if result["input_count"] else 0.0
    )
    metric_cols[3].metric("Statement reduction", f"{reduction:.1f}%")

    results_tab, diff_tab, log_tab = st.tabs(["Optimized code", "Before / after diff", "Compiler summary"])
    with results_tab:
        st.code(result["output"] or "# No output statements", language="text")
        st.caption("The output is produced by your existing C + Flex executable; the dashboard does not reimplement the optimizer.")
    with diff_tab:
        diff = "\n".join(
            difflib.unified_diff(
                result["input"].splitlines(),
                result["output"].splitlines(),
                fromfile="input.tac",
                tofile="optimized.tac",
                lineterm="",
            )
        )
        st.code(diff or "No textual changes were made.", language="diff")
    with log_tab:
        st.text(result["summary"] or "No compiler summary was returned.")

st.markdown("---")
st.markdown("### Notes for demonstration")
notes_a, notes_b, notes_c = st.columns(3)
with notes_a:
    st.markdown("**Constant folding**")
    st.code("x = 10 * 3\n# becomes\nx = 30", language="text")
with notes_b:
    st.markdown("**Common sub-expression elimination**")
    st.code("t1 = a + b\nt2 = t1", language="text")
with notes_c:
    st.markdown("**Dead code elimination**")
    st.code("unused = 99\n# removed when never used", language="text")

st.caption("Teaching-project limitation: this optimizer handles straight-line integer TAC. It does not parse C source code or optimize control-flow constructs such as loops and conditional jumps.")
