"""Minimal Streamlit interface for the existing C + Flex TAC optimizer."""

from __future__ import annotations

import difflib
import re
import subprocess
from pathlib import Path
from typing import Any

import streamlit as st


PROJECT_DIR = Path(__file__).resolve().parent
OPTIMIZER = PROJECT_DIR / "optimizer"

EXAMPLES: dict[str, str] = {
    "Complete example": """# Demonstrates all three optimization techniques
a = sourceA
b = sourceB
unused = 99
t1 = a + b
t2 = a + b
constant = 10 * 3
answer = t2 + constant
print answer
""",
    "Constant folding": """# The constant expression is evaluated at compile time
x = 10 * 3
print x
""",
    "Common sub-expression elimination": """# The repeated expression is calculated only once
a = sourceA
b = sourceB
t1 = a + b
t2 = a + b
print t2
""",
    "Dead code elimination": """# The unused assignment should be removed
a = sourceA
unused = 99
print a
""",
}

st.set_page_config(
    page_title="Intermediate Code Optimizer",
    page_icon="⚙️",
    layout="wide",
    initial_sidebar_state="collapsed",
)

st.markdown(
    """
    <style>
      :root { color-scheme: light; }
      .stApp { background: #f7f7fb; color: #202033; }
      [data-testid="stHeader"] { background: rgba(247,247,251,.92); }
      .main .block-container { max-width: 1180px; padding-top: 2rem; padding-bottom: 3rem; }
      h1, h2, h3 { letter-spacing: -.035em; color: #202033; }
      .subtle { color: #77778d; font-size: .94rem; }
      .eyebrow { color: #7068bd; font-size: .72rem; font-weight: 700;
                 letter-spacing: .12em; text-transform: uppercase; }
      .topline { height: 3px; background: #7068bd; border-radius: 9px; margin-bottom: 1.5rem; }
      [data-testid="stMetric"] { background: #fff; border: 1px solid #e9e8f1;
        border-radius: 12px; padding: .8rem 1rem; }
      [data-testid="stMetricLabel"] { color: #77778d !important; }
      [data-testid="stMetricValue"] { color: #29283d !important; }
      .stTextArea textarea { background: #fff !important; color: #25243a !important;
        border: 1px solid #e5e4ee !important; border-radius: 10px !important;
        font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace !important;
        line-height: 1.55 !important; }
      div[data-baseweb="select"] > div { background: #fff; border-color: #e5e4ee; border-radius: 9px; }
      .stButton > button, .stDownloadButton > button { border-radius: 9px; font-weight: 600;
        min-height: 2.55rem; border: 1px solid #deddea; }
      .stButton > button[kind="primary"] { background: #7068bd; border-color: #7068bd; color: white; }
      .stButton > button:hover, .stDownloadButton > button:hover { border-color: #7068bd; color: #5c55a8; }
      [data-testid="stFileUploader"] { background: #fff; border: 1px dashed #dcdbe8; border-radius: 10px; }
      [data-testid="stTabs"] button { font-weight: 600; }
      [data-testid="stCode"] { border-radius: 10px; }
      hr { border-color: #e8e7f0; }
    </style>
    """,
    unsafe_allow_html=True,
)


def count_statements(source: str) -> int:
    """Count non-empty, non-comment TAC statements for display."""
    total = 0
    for line in source.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("//"):
            continue
        total += sum(1 for part in line.split(";") if part.strip())
    return total


def build_optimizer() -> tuple[bool, str]:
    try:
        result = subprocess.run(
            ["make"], cwd=PROJECT_DIR, capture_output=True,
            text=True, timeout=60, check=False,
        )
    except FileNotFoundError:
        return False, "`make` was not found. Install Flex and build-essential first."
    except subprocess.TimeoutExpired:
        return False, "Compilation timed out."

    log = "\n".join(
        part for part in (result.stdout.strip(), result.stderr.strip()) if part
    )
    if result.returncode != 0:
        return False, log or "The C/Flex optimizer could not be compiled."
    return True, log or "Build completed."


def run_optimizer(source: str) -> dict[str, Any]:
    built, build_log = build_optimizer()
    if not built:
        return {"ok": False, "error": build_log}

    try:
        result = subprocess.run(
            [str(OPTIMIZER)], cwd=PROJECT_DIR, input=source,
            capture_output=True, text=True, timeout=15, check=False,
        )
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "Optimization timed out. Check the input and try again."}
    except OSError as exc:
        return {"ok": False, "error": f"Could not start the optimizer: {exc}"}

    if result.returncode != 0:
        return {"ok": False, "error": result.stderr.strip() or result.stdout.strip() or "The optimizer returned an error."}

    summary = result.stderr.strip()
    match = re.search(
        r"(\d+) input statements,\s*(\d+) removed by dead-code elimination",
        summary,
    )
    input_count = int(match.group(1)) if match else count_statements(source)
    removed_count = int(match.group(2)) if match else 0
    output = result.stdout.rstrip("\n")

    return {
        "ok": True,
        "input": source,
        "output": output,
        "summary": summary,
        "input_count": input_count,
        "output_count": count_statements(output),
        "removed_count": removed_count,
        "build_log": build_log,
    }


# Keep the editor content and last run across Streamlit reruns.
st.session_state.setdefault("tac_input", EXAMPLES["Complete example"])
st.session_state.setdefault("last_result", None)

# Header
st.markdown('<div class="topline"></div>', unsafe_allow_html=True)
header_left, header_right = st.columns([4, 1])
with header_left:
    st.markdown('<div class="eyebrow">Compiler design · Mini project</div>', unsafe_allow_html=True)
    st.title("Intermediate Code Optimizer")
    st.markdown(
        '<p class="subtle">Optimize three-address code with your existing C and Lex engine.</p>',
        unsafe_allow_html=True,
    )
with header_right:
    st.markdown("<div style='height:1.9rem'></div>", unsafe_allow_html=True)
    if OPTIMIZER.exists():
        st.success("C / Flex engine", icon="✓")
    else:
        st.warning("Build on first run", icon="⚙")

# Small, functional input controls.
controls = st.columns([2.2, 1.3, 1.5])
with controls[0]:
    chosen_example = st.selectbox("Example", list(EXAMPLES.keys()))
with controls[1]:
    if st.button("Load example", use_container_width=True):
        st.session_state.tac_input = EXAMPLES[chosen_example]
        st.session_state.last_result = None
        st.rerun()
with controls[2]:
    uploaded = st.file_uploader("Upload .tac", type=["tac", "txt"], label_visibility="collapsed")
    if uploaded is not None and st.button("Use uploaded file", use_container_width=True):
        try:
            st.session_state.tac_input = uploaded.getvalue().decode("utf-8")
            st.session_state.last_result = None
            st.rerun()
        except UnicodeDecodeError:
            st.error("Please upload a UTF-8 text file.")

st.markdown("---")
input_col, output_col = st.columns(2, gap="large")

with input_col:
    st.subheader("Input code")
    st.caption("Edit the three-address code below.")
    st.text_area(
        "Input TAC", key="tac_input", height=330,
        label_visibility="collapsed",
        help="Use one statement per line. Keep required results observable with print.",
    )
    st.caption(f"{count_statements(st.session_state.tac_input)} statements")
    run_clicked = st.button("Run optimization", type="primary", use_container_width=True)
    if run_clicked:
        if not st.session_state.tac_input.strip():
            st.session_state.last_result = None
            st.error("Enter some intermediate code first.")
        else:
            with st.spinner("Running the C + Flex optimizer…"):
                st.session_state.last_result = run_optimizer(st.session_state.tac_input)

with output_col:
    st.subheader("Optimized code")
    st.caption("Generated by the C optimization engine.")
    result = st.session_state.last_result
    if result and result.get("ok"):
        st.code(result["output"] or "# No output", language="text")
        st.download_button(
            "Download optimized TAC",
            data=(result["output"] + "\n") if result["output"] else "",
            file_name="optimized.tac", mime="text/plain", use_container_width=True,
        )
    elif result:
        st.error("Optimization failed")
        st.code(result.get("error", "Unknown error"), language="text")
    else:
        st.info("Your optimized code will appear here after you run the optimizer.")
        st.code("# Waiting for input…", language="text")

# Results are shown only after a successful run.
if result and result.get("ok"):
    st.markdown("---")
    st.subheader("Run summary")
    metric_cols = st.columns(3)
    metric_cols[0].metric("Input statements", result["input_count"])
    metric_cols[1].metric("Output statements", result["output_count"])
    metric_cols[2].metric("Dead assignments removed", result["removed_count"])

    compare_tab, details_tab = st.tabs(["Compare changes", "Compiler details"])
    with compare_tab:
        diff = "\n".join(
            difflib.unified_diff(
                result["input"].splitlines(), result["output"].splitlines(),
                fromfile="input.tac", tofile="optimized.tac", lineterm="",
            )
        )
        st.code(diff or "No textual changes.", language="diff")
    with details_tab:
        st.code(result["summary"] or "Optimization completed.", language="text")
        with st.expander("Build log"):
            st.code(result["build_log"] or "No additional build output.", language="text")

with st.expander("Supported optimizations and input format"):
    st.markdown(
        """- **Constant folding:** evaluates arithmetic expressions made up of constants.
- **Common sub-expression elimination:** reuses a previously calculated expression.
- **Dead code elimination:** removes assignments whose results are never used.

Use one three-address statement per line, such as `x = 10 * 3` or `print x`. The current compiler handles straight-line integer TAC; it does not support loops, branches, functions, arrays or floating-point values. All three optimization passes run together in the C program."""
    )

st.markdown("---")
st.caption("Built with Streamlit · C · Lex/Flex")
