MINIMAL DASHBOARD UPDATE

This ZIP contains the replacement app.py only. Extract it into the existing
intermediate-code-generator project folder, overwriting its current app.py.

In your GitHub Codespace, from:
  /workspaces/IntermediatecodeGenerator/intermediate-code-generator
run:
  unzip -o ../minimal-dashboard-update.zip

Then stop any running Streamlit process with Ctrl+C and launch:
  streamlit run app.py --server.address 0.0.0.0 --server.port 8503

Open port 8503 from the VS Code Ports tab.
